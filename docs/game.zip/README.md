# Растяпа. Между этажами

Растяпа и Ананас знакомятся в дождливом подъезде и встречают закат на крыше. Пять выборов, четыре концовки и 22 кадра.

## Локальный запуск

1. Распакуйте проект. Папка проекта `rasteryapa` содержит каталог `game`.
2. В [Ren’Py 8.5.3](https://www.renpy.org/release/8.5.3) откройте Launcher. Укажите папку, **в которой лежит** `rasteryapa`, как каталог проектов.
3. Выберите `rasteryapa` и нажмите **Launch Project**. Для проверки скрипта используйте **Check Script (Lint)**.

## Веб-сборка и GitHub Pages

- Готовая веб-сборка поставляется отдельным ZIP. Чтобы пересобрать её из исходников, выберите **Web (Beta) → Build Web Application** в Launcher. При первом запуске Launcher предложит загрузить поддержку веб-экспорта. [Документация Ren’Py](https://www.renpy.org/doc/html/web.html)
- Для локальной проверки распакуйте веб-архив и из его каталога запустите `python3 -m http.server 8000`. Откройте `http://localhost:8000/`.
- Для публикации распакуйте веб-архив в `docs/` выбранной ветки. Убедитесь, что `index.html` и `.nojekyll` лежат непосредственно в `docs/`. В **Settings → Pages** выберите **Deploy from a branch**, эту ветку и папку **/docs**. После публикации ссылку из Pages можно отправить в Telegram. [Документация GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

## Файлы игры

- `game/script.rpy` — диалоги, выборы, шкала симпатии и финалы.
- `game/screens.rpy` — портретный интерфейс 720 × 1280.
- `game/images/` — кадры из раскадровки и исходных иллюстраций в WebP.
- `game/audio/` — фортепианная тема, шум дождя и звуки сцен. Звук можно отключить кнопкой в верхней части экрана.
